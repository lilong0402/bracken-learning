package top.lilong.service;

public class MyService {
    public void say(){
        System.out.println("myService");
    }
    
}
