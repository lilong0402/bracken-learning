package top.lilong.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
//@NoArgsConstructor
//@AllArgsConstructor
public class Pet {
    private String type;
    private String name;
}
