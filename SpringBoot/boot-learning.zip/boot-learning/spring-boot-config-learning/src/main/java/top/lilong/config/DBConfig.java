package top.lilong.config;

public interface DBConfig {
    String configure();
}
