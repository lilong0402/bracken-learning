package com.example.springbootgloballexceptionlearning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootGloballExceptionLearningApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootGloballExceptionLearningApplication.class, args);
    }

}
