package com.example.springbootgloballexceptionlearning.handler;

/**
 * @version 1.0
 * @Author 李龙
 * @Date 2023/3/28 14:17
 * @注释
 */
public class GlobalResponseAdvice {
}
