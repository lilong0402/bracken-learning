package com.example.springbootgloballexceptionlearning.consts;

/**
 * @version 1.0
 * @Author 李龙
 * @Date 2023/3/28 14:15
 * @注释
 */
public interface MsgConsts {
    String INPUT_ERROR ="输入的数据错误或没有访问权限！";;
    String SYSYEM_ERROR="系统出现异常，请稍后再试或练习管理员";
    String OTHER_ERROR="系统出现未知异常，请练习管理员";
    String PARAM_ERROR="参数非法";
}
