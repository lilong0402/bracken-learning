package com.example.springbootgloballexceptionlearning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootGloballExceptionLearningApplicationTests {

    @Test
    void contextLoads() {
    }

}
